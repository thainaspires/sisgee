from django.apps import AppConfig


class EstagioConfig(AppConfig):
    name = 'estagio'
