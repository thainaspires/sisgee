package br.cefetrj.sisgee.control;

import java.util.List;

import br.cefetrj.sisgee.model.dao.GenericDAO;
import br.cefetrj.sisgee.model.dao.PersistenceManager;
import br.cefetrj.sisgee.model.entity.Aluno;
import br.cefetrj.sisgee.model.entity.ProfessorOrientador;

public class ProfessorOrientadorServices {
	
	/**
	 * Mostra uma lista com os professores orientadores
	 * @return retorna uma lista com os professores orientadores cadastrados
	 */
	public static List<ProfessorOrientador> listarProfessoresOrientadores(){
		GenericDAO<ProfessorOrientador> professorOrientadorDAO = 
				PersistenceManager.createGenericDAO(ProfessorOrientador.class);
		return professorOrientadorDAO.buscarTodos();
	}
	
	/**
	 * Busca e exibe um professor orientador específico através do seu id
	 * @param id
	 * @return um objeto do tipo ProfessorOrientador, que é passado através do seu id
	 */
	public static ProfessorOrientador buscarProfessorOrientador(Long id){
		GenericDAO<ProfessorOrientador> professorOrientadorDAO = 
				PersistenceManager.createGenericDAO(ProfessorOrientador.class);
		return professorOrientadorDAO.buscar(id);
	}
}
