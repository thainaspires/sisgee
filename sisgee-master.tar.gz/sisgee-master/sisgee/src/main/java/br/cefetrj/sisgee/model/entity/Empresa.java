package br.cefetrj.sisgee.model.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

/**
 * Entidade Empresa
 * @author Anderson Luiz
 * @since 1.0
 *
 */
@Entity
public class Empresa {
	@Id
	@GeneratedValue
	@Column(columnDefinition="integer")
	private Long idEmpresa;
	@Column(columnDefinition="CHAR(14)",nullable=false)
	private String cnpjEmpresa;
	@Column(columnDefinition="VARCHAR(100)")
	private String nomeEmpresa;
	
	@ManyToOne(fetch=FetchType.EAGER)
	private AgenteIntegracao agenteIntegracao;
	
	@OneToMany(mappedBy="empresa")
	private List<Convenio> convenios;
	
	public AgenteIntegracao getAgenteIntegracao(){
		return agenteIntegracao;
	}
	public Long getIdEmpresa() {
		return idEmpresa;
	}

	public void setIdEmpresa(Long idEmpresa) {
		this.idEmpresa = idEmpresa;
	}

	public String getCnpjEmpresa() {
		return cnpjEmpresa;
	}

	public void setCnpjEmpresa(String cnpjEmpresa) {
		this.cnpjEmpresa = cnpjEmpresa;
	}

	public String getNomeEmpresa() {
		return nomeEmpresa;
	}

	public void setNomeEmpresa(String nomeEmpresa) {
		this.nomeEmpresa = nomeEmpresa;
	}

	public List<Convenio> getConvenios() {
		return convenios;
	}

	public void setConvenios(List<Convenio> convenios) {
		this.convenios = convenios;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idEmpresa == null) ? 0 : idEmpresa.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Empresa other = (Empresa) obj;
		if (idEmpresa == null) {
			if (other.idEmpresa != null)
				return false;
		} else if (!idEmpresa.equals(other.idEmpresa))
			return false;
		return true;
	}
	
	public void setAgenteIntegracao(AgenteIntegracao agenteIntegracao) {
		this.agenteIntegracao = agenteIntegracao;
	}
	@Override
	public String toString() {
		return "Empresa [nomeEmpresa=" + nomeEmpresa + "]";
	}
	
	
	
}
