package br.cefetrj.sisgee.control;

import java.util.List;

import br.cefetrj.sisgee.model.dao.GenericDAO;
import br.cefetrj.sisgee.model.dao.PersistenceManager;
import br.cefetrj.sisgee.model.dao.TermoAditivoDAO;
import br.cefetrj.sisgee.model.entity.Aluno;
import br.cefetrj.sisgee.model.entity.TermoAditivo;

public class TermoAditivoServices {
	
	/**
	 * O método lista os termos aditivos vinculados à matricula
	 * @param matricula
	 * @return retorna uma lista com os termos aditivos vinculados.
	 */
	public static List listarTermosAditivos(String matricula){
		return TermoAditivoDAO.listarTermosAditivos(matricula);
	}
	
	/**
	 * O método lista os termos de estágio vinculados à matricula
	 * @param matricula
	 * @return retorna uma lista com os termos vinculados
	 */
	public static List listarTermoEstagio(String matricula){
		return TermoAditivoDAO.listarTermoEstagio(matricula);
	}
	
	/**
	 * O método retorna o termos aditivos pesquisado através do id
	 * @param id
	 * @return um objeto do tipo TermoAditivo vinculado ao id
	 */
	public static TermoAditivo BuscarTermoAditivo(Long id){
		GenericDAO<TermoAditivo> termoAditivoDAO = PersistenceManager.createGenericDAO(TermoAditivo.class);
		return termoAditivoDAO.buscar(id);
	}
}
