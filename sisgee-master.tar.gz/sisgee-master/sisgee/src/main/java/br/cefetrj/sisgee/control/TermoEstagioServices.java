package br.cefetrj.sisgee.control;

import java.util.Date;

import br.cefetrj.sisgee.model.dao.GenericDAO;
import br.cefetrj.sisgee.model.dao.PersistenceManager;
import br.cefetrj.sisgee.model.dao.TermoEstagioDAO;
import br.cefetrj.sisgee.model.entity.TermoEstagio;

/**
 * Trata servicos relacionados ao TermoEstagio
 * 
 * @author Alexander Hugo
 */
public class TermoEstagioServices {
	
	/**
	 * Busca termo a partir do id do aluno
	 * @param id
	 * @return retorna um objeto do tipo TermoEstagio
	 */
	public static TermoEstagio buscarTermoPorIdAluno(Long id){
		return TermoEstagioDAO.buscarTermoPorIdAluno(id);
	}
	
	/**
	 *  Altera o termo estagio enviando o termo para ser alterado e a data da rescisão
	 * @param termo
	 * @param data_Rescisao
	 */
	public static void AlterarTermoEstagio(TermoEstagio termo, Date data_Rescisao){
		TermoEstagioDAO.AlterarTermoEstagio(termo, data_Rescisao);
	}
	
	/**
	 * Imclui um termo estágio
	 * @param termo
	 */
	public static void IncluirTermoEstagio(TermoEstagio termo){
		TermoEstagioDAO.IncluirTermoEstagio(termo);
	}
	
	/**
	 * Busca um termo estágio a partir do id
	 * @param id
	 * @return retorna um objeto do tipo TermoEstagio
	 */
	public static TermoEstagio BuscarTermoEstagio(Long id){
		GenericDAO<TermoEstagio> termoEstagioDAO = PersistenceManager.createGenericDAO(TermoEstagio.class);
		return termoEstagioDAO.buscar(id);
	}
}
